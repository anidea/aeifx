#pragma once

int freeMemory();